function butt(){
    alert("平均值为："+
        (Number(document.getElementById("text3").value) +
         Number(document.getElementById("text3").value) +
         Number(document.getElementById("text3").value) )
         /3
        );
}