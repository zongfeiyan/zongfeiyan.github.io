function kai(){
    document.getElementById("pho").src="./img/kai.png";
}
function guan(){
    document.getElementById("pho").src="./img/guan.png";
}